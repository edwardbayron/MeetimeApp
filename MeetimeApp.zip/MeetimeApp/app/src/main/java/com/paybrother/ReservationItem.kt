package com.paybrother

class ReservationItem (var id: Long, var name: String, var event: String, var date: String)
