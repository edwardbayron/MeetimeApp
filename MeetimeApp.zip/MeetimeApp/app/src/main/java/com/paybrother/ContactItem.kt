package com.paybrother

data class ContactItem (
    val firstName: String,
    val lastName: String
    )